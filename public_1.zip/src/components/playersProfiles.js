const Players = {
    Foxie: {
        name: "Foxie",
        image: "assets/profiles/foxie.jpg",
        rank: "beginner",
    },
    Owl: {
        name: "Owl",
        image: "assets/profiles/owl.jpg",
        rank: "guru"
    },
    Wofie: {
        name: "Wolfie",
        image: "assets/profiles/wolf.jpg",
        rank: "vodoo"
    },
    Clumsy: {
        name: "Clumsy",
        image: "assets/profiles/clumsy.jpg",
        rank: "noob"
    },
    Susan: {
        name: "Susan",
        image: "assets/profiles/susan.jpeg",
        rank: "hooooh!!"
    },
    Guest: {
        name: "Guest",
        image: "assets/profiles/guest.jpg",
        rank: "lopooooh!!"
    }
}

export default Players