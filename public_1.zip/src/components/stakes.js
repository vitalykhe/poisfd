export const minStake = 20;
export const maxStake = 300;
